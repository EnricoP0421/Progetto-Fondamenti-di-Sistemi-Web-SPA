const Home = {
  template: `
    <div class="container py-4 page-content active">
      <h1 class="title-center">{{ title }}</h1>
      <div v-html="content"></div>
    </div>
  `,
  data() {
    return {
      title: "React Native: una nuova visione per lo sviluppo mobile",
      content: `
      <main class="container py-4">  
        <div class="d-flex flex-md-row flex-column-reverse align-items-center mb-4">
            
            <div class="flex-grow-1">
              <p>
                Nel panorama in continua evoluzione dello sviluppo software, React Native si è affermato come una tecnologia di riferimento per la creazione di applicazioni mobili moderne, dinamiche e accessibili. 
                Sviluppato da Facebook e rilasciato nel 2015 come progetto open source, React Native ha da subito attratto l'interesse della comunità di sviluppatori grazie alla sua promessa: 
                <strong>costruire app mobili nativamente, usando JavaScript</strong>.
              </p>
             <img src="https://reactnative.dev/img/header_logo.svg" alt="React Native Logo" class="img-sinistra">
              <p>
                Prima della sua nascita, la maggior parte delle aziende sviluppava due applicazioni distinte: una in Java/Kotlin per Android e una in Swift/Objective-C per iOS. 
                Questa strategia comportava tempi lunghi, costi elevati e la necessità di mantenere due team separati. 
                Altre soluzioni ibride, come Cordova o Ionic, permettevano di riutilizzare il codice web ma sacrificavano prestazioni e fluidità, poiché l'app veniva eseguita dentro una WebView. 
                React Native ha superato questi limiti, offrendo <strong>componenti realmente nativi</strong> e prestazioni vicine alle app sviluppate in linguaggio nativo.
              </p>
               
              <p>
                Uno degli aspetti che ha reso React Native così popolare è la possibilità di <strong>riutilizzare gran parte del codice</strong> tra Android e iOS. 
                Questo approccio consente una <strong>riduzione significativa dei tempi e dei costi di sviluppo</strong>, rendendolo una scelta molto popolare tra startup e grandi aziende.
              </p>
            </div>
          </div>

          <div class="d-flex flex-md-row flex-column align-items-center mb-4">
            
            <div class="flex-grow-1 pe-md-4">
              <p>
                React Native non è solo un framework, ma un vero <strong>paradigma di sviluppo</strong>. 
                Si basa sul concetto di componenti riutilizzabili e di programmazione dichiarativa, gli stessi principi che hanno reso React uno strumento così diffuso nel web.
              </p>
              <img src="immagini/img-react-native.png" alt="immagine react native" class="img-destra"/>
              <p>
                Il suo ecosistema è ampio e dinamico. Gli sviluppatori possono sfruttare librerie note del mondo JavaScript (Redux, Axios, Moment.js, ecc.), 
                mantenendo la possibilità di integrare moduli nativi quando necessario. 
                Questo consente un equilibrio tra <strong>produttività e controllo</strong>, creando esperienze utente fluide e personalizzate.
              </p>
              <p>
                Numerose aziende lo utilizzano con successo: <strong>Facebook</strong> (che lo ha creato), <strong>Instagram</strong> (per funzioni come le Storie), 
                <strong>Tesla</strong> (per controllare le auto elettriche da remoto), <strong>Uber Eats</strong> e <strong>Discord</strong>. 
                Questi casi mostrano come React Native sia adatto anche ad applicazioni complesse con milioni di utenti.
              </p>
              <p>
              <img src="immagini/blog-banner.jpg" alt="immagine react native" class="img-elenco"/> 
                Rispetto ad altri framework multipiattaforma:
                <ul class="img-bullet">
                  <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>Flutter</strong> (Google): usa Dart e un motore grafico proprietario, offre grande uniformità ma è meno vicino all’ecosistema web.</li>
                  <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>Xamarin</strong> (Microsoft): basato su C#, potente ma più difficile da adottare per sviluppatori web.</li>
                  <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>Ionic/Cordova</strong>: facili da usare ma meno performanti, basati su WebView.</li>
                </ul>
              </p>
              
              <p>
                Naturalmente non mancano le sfide: per alcune funzioni molto specifiche occorre scrivere codice nativo; 
                inoltre, la dipendenza da librerie esterne può portare a problemi di compatibilità. 
                Tuttavia, con la <strong>New Architecture</strong> (Fabric e TurboModules), React Native si avvicinerà ancora di più alle performance del nativo puro.
              </p>
              <p>
                In conclusione, React Native rappresenta oggi un <strong>ponte tra web e mobile</strong>, 
                permettendo di sfruttare le competenze di React anche su smartphone e tablet. 
                Unisce produttività e flessibilità, diventando una scelta strategica per chi vuole creare app moderne e scalabili.
              </p>
            </div>
          </div>

          <hr class="my-4" />
          <p class="fst-italic text-muted text-center">
            In questa SPA approfondiremo React Native attraverso una panoramica strutturata che ne esplora caratteristiche, vantaggi, limiti e prospettive future.
          </p>
      </main>
      `
    };
  }
};


const Api = {
  template: `
    <div class="container py-4 page-content active">
      <h1 class="title-center">{{ title }}</h1>
      <div v-html="content"></div>
    </div>
  `,
  data() {
    return {
      title: "React Native: applicazione pratica",
      content: `
      <main class="container py-4">
        <p>
          Per lo sviluppo di un software con React Native bisogna innanzitutto installare <strong>Node.js</strong>, 
          <strong>Expo CLI</strong> e un simulatore (oppure da smartphone l'app Expo Go).
        </p>
          
          <h3>Installazione e Setup</h3>
          <p>
            Node.js è fondamentale perché permette di eseguire JavaScript al di fuori del browser. 
            Expo CLI è invece un insieme di strumenti che semplifica lo sviluppo, evitando configurazioni complicate con Android Studio o Xcode. 
            Esiste anche la React Native CLI, più complessa ma utile se si vuole un controllo totale.
          </p>
          <p>
            Per creare un progetto si installa Expo CLI da terminale con <mark>npm install -g expo-cli</mark>, 
            poi si digita <mark>expo init HelloReactNative</mark>. 
            Expo chiederà che tipo di progetto si vuole creare: la scelta più semplice è <mark>blank (a minimal app as clean as an empty canvas)</mark>. 
            Successivamente si seleziona JavaScript come linguaggio.
          </p>
          
          <p>
            Expo creerà una cartella HelloReactNative con tutto il necessario per far partire l'app. 
            Per avviarla si digita:
          </p>
          <div class="code-block">
            cd HelloReactNative<br>
            expo start
          </div>
          
          <p>
            Nel terminale comparirà un QR code: scansionandolo con l'app Expo Go si può aprire immediatamente l'app sullo smartphone, 
            testando in tempo reale le modifiche senza dover ricompilare manualmente.
          </p>

          <h3>Sintassi di Base</h3>
          <p>I componenti fondamentali di React Native sono:</p>
          <ul class="img-bullet">
             <li><img src="immagini/reacticona.svg" alt="icona react"/>v<strong>useState</strong>: hook per gestire lo stato (es. messaggi, contatori, valori booleani).</li>
             <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>View</strong>: contenitore, simile a un div HTML, organizzato con Flexbox.</li>
             <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>Text</strong>: per visualizzare stringhe di testo.</li>
             <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>Button</strong>: bottone cliccabile, con evento onPress.</li>
             <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>TextInput</strong>: campo per inserire testo (utile in login e form).</li>
             <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>FlatList</strong>: per mostrare liste lunghe in modo performante.</li>
             <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>StyleSheet.create</strong>: definisce stili CSS-like in maniera organizzata.</li> 
          </ul>
          
          <h3>Esempio Pratico 1: Hello World Evoluto</h3>
          <p>Un primo esempio di codice App.js che mostra un messaggio e lo cambia quando si preme un bottone:</p>
          <div class="code-block">
            <img src="immagini/app_js_syntax.png" width="700px" alt="codice Hello World"/>
          </div>
          
          <p>
            Dopo aver lanciato <mark>expo start</mark>, si vedrà un QR nel terminale: 
            scansionandolo con Expo Go si potrà testare l'app in tempo reale sul proprio smartphone.
          </p>
          
          <div class="alert alert-info">
            <h4>💡 Questo esempio è il "Hello World evoluto" di React Native</h4>
            <ul>
              <li>Introduce alla struttura di un'app mobile</li>
              <li>Mostra l'interazione con l'utente (evento click)</li>
              <li>Permette di usare componenti, stato, eventi e stile</li>
            </ul>
          </div>

          <h3>Esempio Pratico 2: Lista della Spesa</h3>
          <p>
            Un secondo esempio consiste in una semplice lista della spesa, 
            dove l'utente può aggiungere prodotti e vederli comparire subito nell'interfaccia:
          </p>
          <div class="code-block">
            <img src="immagini/lista_spesa.png" width="700px" alt="codice lista della spesa"/>
          </div>

          <p>
            Qui entrano in gioco <strong>TextInput</strong> per l'inserimento dati e <strong>FlatList</strong> per visualizzarli, 
            mostrando come gestire input e liste dinamiche.
          </p>

          <h3>Esempio Pratico 3: Contatore</h3>
          <p>
            Un altro esempio didattico è un contatore con due pulsanti (incrementa e decrementa). 
            Serve a comprendere come gestire valori numerici e aggiornare lo stato a ogni interazione.
          </p>
          <div class="code-block">
            <img src="immagini/contatore.png" width="700px" alt="codice contatore"/>
          </div>

          <h3>Gestione degli Stili</h3>
          <p>
            Gli stili in React Native si definiscono con <strong>StyleSheet.create</strong>, 
            usando nomi camelCase come <code>backgroundColor</code> o <code>fontSize</code>. 
            Questo approccio ricorda il CSS, ma con sintassi più vicina a JavaScript.
          </p>
          <p>Esempio:</p>
          <div class="code-block">
            const styles = StyleSheet.create({
              titolo: {
                fontSize: 22,
                fontWeight: 'bold',
                color: 'blue',
                margin: 10
              }
            });
          </div>

          <h3>Debug e Strumenti</h3>
          <p>
            Durante lo sviluppo, React Native offre diversi strumenti:
          </p>
          <ul class="img-bullet">
            <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>Fast Refresh</strong>: aggiorna subito l'app dopo ogni modifica.</li>
            <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>console.log</strong>: per stampare valori e verificare il flusso del codice.</li>
            <li><img src="immagini/reacticona.svg" alt="icona react"/><strong>React Developer Tools</strong>: permette di analizzare i componenti e il loro stato.</li>
          </ul>

          <h3>Considerazioni Finali</h3>
          <p>
            La parte pratica mostra come, con pochi comandi e componenti base, 
            sia possibile creare applicazioni mobili complete e interattive. 
            Grazie all'uso di Expo e alle librerie dell'ecosistema, lo sviluppo risulta veloce e accessibile anche a chi proviene dal web.
          </p>
      </main>
      `
    };
  }
};

const Esempio = {
  template: `
    <div class="container py-4 page-content active">
      <h1 class="title-center">{{ title }}</h1>
      <div v-html="content"></div>
    </div>
  `,
  data() {
    return {
      title: "Catalogo dei componenti React Native",
      content: `
      <main class="container py-4">
        <p class="text-center mb-4">Una raccolta dei componenti base e avanzati usati nello sviluppo mobile con React Native.</p>
      
        <div class="table-responsive">
          <table class="table table-bordered table-striped table-hover react-table">
            <thead class="table-dark">
              <tr>
                <th>Nome</th>
                <th>Descrizione</th>
                <th>Categoria</th>
                <th>Popularità</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>View</td><td>Contenitore base per layout e stile</td><td>UI</td><td>★★★★★</td></tr>
              <tr><td>Text</td><td>Mostra testo su schermo</td><td>UI</td><td>★★★★★</td></tr>
              <tr><td>Image</td><td>Mostra un'immagine</td><td>UI</td><td>★★★★☆</td></tr>
              <tr><td>TextInput</td><td>Campo di input testuale</td><td>Form</td><td>★★★★☆</td></tr>
              <tr><td>Button</td><td>Pulsante semplice</td><td>UI</td><td>★★★★☆</td></tr>
              <tr><td>ScrollView</td><td>Contenitore scrollabile</td><td>Layout</td><td>★★★★☆</td></tr>
              <tr><td>FlatList</td><td>Lista performante per molti elementi</td><td>Lista</td><td>★★★★☆</td></tr>
              <tr><td>SectionList</td><td>Lista divisa in sezioni</td><td>Lista</td><td>★★★☆☆</td></tr>
              <tr><td>TouchableOpacity</td><td>Elemento toccabile con effetto opacità</td><td>Interazione</td><td>★★★★☆</td></tr>
              <tr><td>TouchableHighlight</td><td>Elemento toccabile con effetto evidenziato</td><td>Interazione</td><td>★★★☆☆</td></tr>
              <tr><td>Pressable</td><td>Componente moderno per interazione touch</td><td>Interazione</td><td>★★★★☆</td></tr>
              <tr><td>Modal</td><td>Finestra modale</td><td>UI</td><td>★★★☆☆</td></tr>
              <tr><td>ActivityIndicator</td><td>Indicatore di caricamento</td><td>UI</td><td>★★★☆☆</td></tr>
              <tr><td>Switch</td><td>Interruttore on/off</td><td>Form</td><td>★★★☆☆</td></tr>
              <tr><td>KeyboardAvoidingView</td><td>Gestisce l'overlay della tastiera</td><td>Layout</td><td>★★★☆☆</td></tr>
              <tr><td>SafeAreaView</td><td>Evita le zone non sicure dello schermo</td><td>Layout</td><td>★★★★☆</td></tr>
              <tr><td>StatusBar</td><td>Controlla la barra di stato</td><td>UI</td><td>★★★☆☆</td></tr>
              <tr><td>RefreshControl</td><td>Gestisce il refresh via pull</td><td>Lista</td><td>★★★☆☆</td></tr>
              <tr><td>Animated</td><td>Gestione avanzata di animazioni</td><td>Animazioni</td><td>★★★★☆</td></tr>
              <tr><td>PanResponder</td><td>Gestione gesture avanzate</td><td>Interazione</td><td>★★★☆☆</td></tr>
            </tbody>
          </table>
        </div>
      </main>
      `
    };
  }
};


const Inserimento = {
  data() {
    return {
      esami: [],
      selected: 0,
      nuovoEsame: { corso: '', voto: '' }
    };
  },
  created() {
    const STORAGE_KEY = 'esami-salvati';
    const salvati = localStorage.getItem(STORAGE_KEY);
    if (salvati) {
      try {
        this.esami = JSON.parse(salvati);
      } catch (e) {
        console.error("Errore nel parsing dei dati salvati:", e);
        this.initDefault();
      }
    } else {
      this.initDefault();
    }
  },
  methods: {
    storageKey() {
      return 'esami-salvati';
    },
    salvaEsami() {
      localStorage.setItem(this.storageKey(), JSON.stringify(this.esami));
    },
    initDefault() {
      this.esami = [
        { corso: "Programmazione", voto: 24 },
        { corso: "Elementi di Matematica per l'Informatica", voto: 27 },
        { corso: "Reti di Calcolatori e Programmazione di Rete", voto: 22 }
      ];
      this.selected = 0;
      this.salvaEsami();
    },
    aggiungiEsame() {
      const voto = parseInt(this.nuovoEsame.voto);
      if (
        this.nuovoEsame.corso.trim() &&
        !isNaN(voto) &&
        voto >= 18 &&
        voto <= 30
      ) {
        this.esami.push({
          corso: this.nuovoEsame.corso.trim(),
          voto: voto
        });
        this.nuovoEsame.corso = '';
        this.nuovoEsame.voto = '';
        this.salvaEsami();
      } else {
        alert("Il voto deve essere un numero tra 18 e 30.");
      }
    },
    eliminaEsame(index) {
      if (confirm(`Vuoi davvero eliminare ${this.esami[index].corso}?`)) {
        this.esami.splice(index, 1);
        if (this.selected >= this.esami.length) {
          this.selected = this.esami.length - 1;
        }
        this.salvaEsami();
      }
    },
    ripristinaEsami() {
      if (confirm("Vuoi davvero ripristinare i dati iniziali?")) {
        localStorage.removeItem(this.storageKey());
        this.initDefault();
      }
    }
  },
  watch: {
    esami: {
      handler() {
        this.salvaEsami();
      },
      deep: true
    }
  },
  template: `
    <div class="py-4">
      <h1 class="title-center">Inserimento, eliminazione e modifica dati</h1>
      <main class="container">
      <div>
        <h2>Esami dati:</h2>
        <ul class="img-bullet">
          <li v-for="esame in esami" :key="esame.corso">
            <img src="immagini/reacticona.svg" alt="icona react"/>
            {{ esame.corso + " " + esame.voto }}
          </li>
        </ul>
        <hr/>
        <form>
          <h3>Modifica:</h3>
          <ul class="img-bullet">
            <li>
              <label for="esame_selezionato">Esame da modificare:</label>
              <select id="esame_selezionato" v-model="selected">
                <option v-for="(esame, index) in esami" :value="index">
                  {{ esame.corso + " " + esame.voto }}
                </option>
              </select>
            </li>
            <li>
              <label for="corso">Corso:</label>
              <input v-model="esami[selected].corso" type="text" id="corso"/>
            </li>
            <li>
              <label for="voto">Voto:</label>
              <input v-model="esami[selected].voto" type="number" id="voto" min="18" max="30"/>
            </li>
          </ul>
        </form>
        <hr/>
        <form @submit.prevent="aggiungiEsame">
          <h3>Aggiungi:</h3>
          <ul class="img-bullet">
            <li>
              <label for="nuovo_corso">Corso:</label>
              <input v-model="nuovoEsame.corso" type="text" id="nuovo_corso"/>
            </li>
            <li>
              <label for="nuovo_voto">Voto:</label>
              <input v-model="nuovoEsame.voto" type="number" id="nuovo_voto" min="18" max="30"/>
            </li>
            <button type="submit">Aggiungi</button>
          </ul>
        </form>
        <hr/>
        <h3>Elimina:</h3>
        <ul class="img-bullet">
          <li v-for="(esame, index) in esami" :key="index">
            <img src="immagini/reacticona.svg" alt="icona react"/>
            {{ esame.corso }} {{ esame.voto }}
            <button @click="eliminaEsame(index)">Elimina</button>
          </li>
        </ul>
        <button @click="ripristinaEsami">Ripristina dati iniziali</button>
      </div>
    </main>
    </div>
  `
};


const routes = [
  { path: '/', component: Home },
  { path: '/api', component: Api },
  { path: '/esempio', component: Esempio },
  { path: '/inserimento', component: Inserimento }
];

const router = VueRouter.createRouter({
  history: VueRouter.createWebHashHistory(),
  routes
});


const app = Vue.createApp({});
app.use(router);
app.mount('#app');
